﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOK_MANAGEMENT
{
    public abstract class Member_HackHub
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public int Contact { get; set; }
        public string Address { get; set; }
        public string MemeberShip { get; set; }

        public Member_HackHub(string name, string surname, string email, int contact, string address,string membership)
        {
            Name = name;
            Surname = surname;
            Email = email;
            Contact = contact;
            Address = address;
            MemeberShip = membership;
        }
        
    }
}
