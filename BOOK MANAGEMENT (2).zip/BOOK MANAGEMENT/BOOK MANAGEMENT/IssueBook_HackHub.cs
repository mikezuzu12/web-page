﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace BOOK_MANAGEMENT
{
    internal class IssueBook_HackHub: BookManagement_HackHub
    {
        public DateTime IssueDate { get; set; }
        public DateTime Duedate { get; set; }

     
        public IssueBook_HackHub (DateTime issuedate, DateTime duedate, string title, string author, string publisher, DateTime publisheDate, decimal price, int quantity)
            :base(title, author, publisher, publisheDate, price, quantity)
            
            
        {
            IssueDate = issuedate;
            Duedate = duedate;

        }

    }
}
