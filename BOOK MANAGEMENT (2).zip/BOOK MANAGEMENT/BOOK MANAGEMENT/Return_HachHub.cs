﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOK_MANAGEMENT
{
    internal class Return_HachHub : BookManagement_HackHub
    {
        public DateTime DueDate { get; set; } 
        public DateTime ReturnDate { get; set; }

        public Return_HachHub(DateTime duedate, DateTime returndate, string title, string author, string publisher, DateTime publisheDate, decimal price, int quantity)
            :base (title, author, publisher, publisheDate, price, quantity)

        {
            DueDate = duedate;
            ReturnDate = returndate;
        }

    
    }
}
