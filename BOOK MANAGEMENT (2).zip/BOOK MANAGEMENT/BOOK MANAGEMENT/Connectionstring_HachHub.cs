﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOK_MANAGEMENT
{
    public class Connection
    {
        string connectionString = "data source=DESKTOP-APG2A6Q\\SQLEXPRESS ; database=prac 1; integrated security=True";
        SqlConnection con;

        public void OpenConnection()
        {
            con = new SqlConnection(connectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            if (con != null)
                {
                con.Close(); // Close the connection
            }
        }
        public SqlDataReader DataReader(string query, Dictionary<string, object> parameters)
        {
            SqlCommand cmd = new SqlCommand(query, con);
            foreach (var param in parameters)
            {
                cmd.Parameters.AddWithValue(param.Key, param.Value);
            }
            SqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        public void ExecuteQueries(string Query_)
        {
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        //public SqlDataReader DataReader(string Query_)
        //{
        //    SqlCommand cmd = new SqlCommand(Query_, con);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    return dr;
        //}
        public void ExecuteParameterizedQuery(string query, Dictionary<string, object> parameters)
        {
            SqlCommand cmd = new SqlCommand(query, con); // Use the open connection
            foreach (var param in parameters)
            {
                cmd.Parameters.AddWithValue(param.Key, param.Value);
            }
            cmd.ExecuteNonQuery();
        }

        public DataTable GetDataTable(string query)
        {
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);  // Fill the DataTable with the data from the query
            return dt;
        }
        //public DataTable GetDataTable(string query, Dictionary<string, object> parameters = null)
        //{
        //    DataTable dt = new DataTable();
        //    using (SqlCommand cmd = new SqlCommand(query, con))
        //    {
        //        // Add parameters if provided
        //        if (parameters != null)
        //        {
        //            foreach (var param in parameters)
        //            {
        //                cmd.Parameters.AddWithValue(param.Key, param.Value);
        //            }
        //        }

        //        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
        //        {
        //            da.Fill(dt); // Fill the DataTable with the query result
        //        }
        //    }

        //    return dt;

        //    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
        //    DataTable dataTable = new DataTable();

        //    // Fill the DataTable with the query results
        //    dataAdapter.Fill(dataTable);

        //    return dataTable;
        //}
    }

}



