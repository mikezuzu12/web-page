﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOK_MANAGEMENT
{
    public abstract class BookManagement_HackHub
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }
        public DateTime PublisheDate { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public string Password { get; set; }
        public string Username { get; set; }

        public BookManagement_HackHub(string title, string author, string publisher, DateTime publisheDate, decimal price, int quantity)
        {
            Title = title;
            Author = author;
            Publisher = publisher;
            PublisheDate = publisheDate;
            Price = price;
            Quantity = quantity;
           
        }
    }
}
