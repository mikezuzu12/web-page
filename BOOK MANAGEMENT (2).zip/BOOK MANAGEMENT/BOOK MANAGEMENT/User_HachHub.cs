﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOK_MANAGEMENT
{
    public class User_HachHub
    {

        public string Name { get; set; }
        public string Email { get; set; }
        public string Position { get; set; }
        public int TelePhone { get; set; }
        public string Address { get; set; }
        public string Password { get; set; }
        public string Username { get; set; }



        public User_HachHub(string name, string email, string position, int telePhone, string password, string username, string address)


        {
            Name = name;
            Email = email;
            Position = position;
            TelePhone = telePhone;
            Password = password;
            Username = username;
            Address = address;
        }
    }
}
